            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Perpustakaan <?= date('Y'); ?></span>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <script src="<?= $base_url; ?>/assets/template/back_office/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?= $base_url; ?>/assets/template/back_office/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="<?= $base_url; ?>/assets/template/back_office/js/sb-admin-2.min.js"></script>
</body>
</html>