    <footer class="footer mt-auto py-3" style="background:#DD4814;">
      <div class="container">
        <span class="text-white">
          <center>
            Copyright &copy; Perpustakaan <?= date('Y'); ?>
          </center>
        </span>
      </div>
    </footer>
    <script src="assets/template/front_office/popper.min.js"></script>
    <script src="assets/template/front_office/bootstrap/bootstrap.min.js"></script>
  </body>
</html>