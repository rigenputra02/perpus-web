<?php 

require 'connection.php'; 

session_destroy();
echo '<script>document.location.href="masuk.php"</script>';